const toggle = document.getElementById('themeToggle');
const html = document.documentElement;

// Apply saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
  html.classList.add('dark-theme');
}

// Toggle logic
toggle.addEventListener('click', () => {
  if (html.classList.contains('dark-theme')) {
    html.classList.remove('dark-theme');
    localStorage.setItem('theme', 'light');
  } else {
    html.classList.add('dark-theme');
    localStorage.setItem('theme', 'dark');
  }
});



















    // Function to delete a product card

    // Display products on page load
    window.onload = displayProducts;
    // JSON Data for products
const products = [
    {
        "name": "1Xbet",
        "image": "./all web images/32.jpg",
        "rate": 4.5,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "Super s9",
        "image": "./all web images/1.webp",
        "rate": 4.9,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "Card rummy",
        "image": "./all web images/2.png",
        "rate": 4.6,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti blue",
        "image": "./all web images/3.jpg",
        "rate": 4.5,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti world",
        "image": "./all web images/8.png",
        "rate": 3.1,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti gold",
        "image": "./all web images/4.png",
        "rate": 3.7,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti gold 2",
        "image": "./all web images/5.png",
        "rate": 4.4,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti Free",
        "image": "./all web images/13.jpg",
        "rate": 4.8,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti tiger",
        "image": "./all web images/14.jpg",
        "rate": 2.9,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti Land",
        "image": "./all web images/6.png",
        "rate": 4.9,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti spin",
        "image": "./all web images/7.jpg",
        "rate": 3.5,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti loot",
        "image": "./all web images/9.png",
        "rate": 2.5,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
        "name": "3 patti room",
        "image": "./all web images/10.jpg",
        "rate": 3.3,
        "buyLink": "https://example.com/samsung-j6"
    },
    {
    "name": "3 patti Best",
    "image": "./all web images/11.png",
    "rate": 4.7,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti sky",
    "image": "./all web images/12.png",
    "rate": 4.8,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti Show",
    "image": "./all web images/15.jpg",
    "rate": 1.5,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti mela",
    "image": "./all web images/16.jpg",
    "rate": 2.7,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti vegas",
    "image": "./all web images/17.png",
    "rate": 1.3,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti lucky",
    "image": "./all web images/18.png",
    "rate": 1.1,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti Happy club",
    "image": "./all web images/19.png",
    "rate": 1.9,
    "buyLink": "https://example.com/samsung-j6"
},
{
    "name": "3 patti Royal",
    "image": "./all web images/20.jpg",
    "rate": 0.8,
    "buyLink": "https://example.com/samsung-j6"
},
{
"name": "3 patti Go",
"image": "./all web images/21.png",
"rate": 2.6,
"buyLink": "https://example.com/samsung-j6"
}
];

// Function to dynamically create product cards
function displayProducts() {
    const cardContainer = document.getElementById('card-container-2');
    products.forEach(product => {
        // Create a card for each product
        const card = document.createElement('div');
        card.classList.add('product-card-2');

        card.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <div class="card-content-2">
                <h3>${product.name}</h3>
                <p><strong>Rate:</strong> ${product.rate} ⭐⭐⭐⭐</p>
                    </select>
                <div class="buttons">
                    <button class="buy-now" onclick="buyNow('${product.buyLink}')">download Now</button>
                </div>
            </div>
        `;

        // Append the card to the container
        cardContainer.appendChild(card);
    });

}

// Function to simulate buying a product and redirecting to the buy link
function buyNow(buyLink) {
    window.location.href = buyLink;
}

// Function to delete a product card

// Display products on page load
window.onload = displayProducts;

















        // sectond container data
        
        
        // Master array to keep track of all containers
        const allContainers = [];
      
        // Function to create new container
        function createContainer(containerId, productArray) {
          const wrapper = document.createElement('div');
          wrapper.className = 'container-wrapper';
      
          const container = document.createElement('div');
          container.className = 'product-container';
          container.id = containerId;
      
          const scrollLeft = document.createElement('button');
          scrollLeft.className = 'scroll-btn scroll-left';
          scrollLeft.innerText = '<';
          scrollLeft.onclick = () => scrollProducts(containerId, -1);
      
          const scrollRight = document.createElement('button');
          scrollRight.className = 'scroll-btn scroll-right';
          scrollRight.innerText = '>';
          scrollRight.onclick = () => scrollProducts(containerId, 1);
      
          const productTrack = document.createElement('div');
          productTrack.className = 'products';
      
          productArray.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
      
            const img = document.createElement('img');
            img.src = product.image;
            img.onclick = () => window.open(product.link, '_blank');
      
            const name = document.createElement('p');
            name.innerText = product.name;
      
            card.appendChild(img);
            card.appendChild(name);
            productTrack.appendChild(card);
          });
      
          container.appendChild(scrollLeft);
          container.appendChild(productTrack);
          container.appendChild(scrollRight);
      
          wrapper.appendChild(container);
          document.getElementById('all-containers').appendChild(wrapper);
      
          allContainers.push({ id: containerId, products: productArray });
        }
      
        // Scroll functionality
        function scrollProducts(containerId, direction) {
          const container = document.querySelector(`#${containerId} .products`);
          const scrollAmount = 220;
          container.scrollLeft += direction * scrollAmount;
        }
      
        // Example Usage:
        createContainer("container1", [
          { name: "1XBET", image: "./all web images/32.jpg", link: "https://example.com/shoe" },
          { name: "SUPER (S9)", image: "./all web images/1.webp", link: "https://example.com/shoe" },
          { name: "CARD RUMMY", image: "./all web images/2.png", link: "https://example.com/watch" },
          { name: "3 patti world", image: "./all web images/8.png", link: "https://example.com/hat" },
          { name: "3 patti blue",image: "./all web images/3.jpg", link: "https://example.com/hat" },
          { name: "92 JEETO", image: "./all web images/36.jpg", link: "https://example.com/shoe" },
          { name: "92 COCO", image: "./all web images/34.jpg", link: "https://example.com/watch" },
          { name: "92 DADO", image: "./all web images/35.jpg", link: "https://example.com/watch" },
          { name: "ALANO GT 2", image: "./all web images/24.jpg", link: "https://example.com/shoe" },
          { name: "ALANO RUNNY", image: "./all web images/27.jpg", link: "https://example.com/hat" },
          { name: "ALANO GT 6", image: "./all web images/28.jpg", link: "https://example.com/shoe" }
        ]);
